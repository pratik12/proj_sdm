package com.sdm.model;

public class Doctor {

	private int doctorId;
	private int doctorName;
	private int status;
	
	
	public int getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}
	public int getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(int doctorName) {
		this.doctorName = doctorName;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	
}
